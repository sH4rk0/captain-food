importScripts("precache-manifest.c0412389d2495bdda86eb370f906b726.js", "https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

workbox.precaching.precacheAndRoute(__precacheManifest);


self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "212659b66a690daf8bbe14c89f08298d",
    "url": "assets/cover.jpg"
  },
  {
    "revision": "91482c69425ec2f370587c1539746c25",
    "url": "assets/css/_notes/dwsync.xml"
  },
  {
    "revision": "b4399b09edd7cc565225da4b9d5316e7",
    "url": "assets/css/global.css"
  },
  {
    "revision": "e1d0acd8bd51eb065be807c4bdf5176b",
    "url": "assets/fonts/arcade.png"
  },
  {
    "revision": "4e1d59fe10df8faec75b3865ee2e77e7",
    "url": "assets/fonts/arcade.xml"
  },
  {
    "revision": "daa0fa588537e5ec3abf3423e27de83b",
    "url": "assets/icons/icons-192.png"
  },
  {
    "revision": "91c0379d0569abbd863e13834e2283ec",
    "url": "assets/icons/icons-512.png"
  },
  {
    "revision": "5ae88cf74dd1b4527888b8cae5c815dd",
    "url": "assets/images/arrow.png"
  },
  {
    "revision": "51e89c235ddd6c51b8e835b4fee493f5",
    "url": "assets/images/bomb-explo.png"
  },
  {
    "revision": "8b2d9272d652321e7409b86c67c52936",
    "url": "assets/images/cap-cannons.png"
  },
  {
    "revision": "b6300e77535d227877d061092b4f492c",
    "url": "assets/images/cap-generic.png"
  },
  {
    "revision": "714642b8d864e2e9db60f17ae0902007",
    "url": "assets/images/cap.png"
  },
  {
    "revision": "b6f1366c57c24490bdefa5df35341ece",
    "url": "assets/images/captain.png"
  },
  {
    "revision": "8f134d91b9ada5b8df264bb88eadaa37",
    "url": "assets/images/cherry.png"
  },
  {
    "revision": "e9a7200d3d47db43a967670f790f2874",
    "url": "assets/images/coldiretti.png"
  },
  {
    "revision": "cb69acdc8974bddadd8d03598b6c746f",
    "url": "assets/images/credist.png"
  },
  {
    "revision": "c7602f679dd12cb18a558f520bddde96",
    "url": "assets/images/credits.png"
  },
  {
    "revision": "9f37a7f185cf77aa4e370227d62ef92d",
    "url": "assets/images/debug.log"
  },
  {
    "revision": "e926b0839c841c007162032b69e80e2b",
    "url": "assets/images/explosionParticles.json"
  },
  {
    "revision": "b6d9383ffef931e26eae8dadf9306e5c",
    "url": "assets/images/explosionParticles.png"
  },
  {
    "revision": "b308e990e3ff047edc5f27868dc6994d",
    "url": "assets/images/faces.png"
  },
  {
    "revision": "32797889d2018dbbb6477af13b3cc671",
    "url": "assets/images/fake-explo.png"
  },
  {
    "revision": "a9732c6fd9fe5311807b7569a99475b2",
    "url": "assets/images/fake.png"
  },
  {
    "revision": "383d0c3c8157f5cafbc3ec211931977c",
    "url": "assets/images/food.png"
  },
  {
    "revision": "e36d1ec3898d2fa55533c0e5835f8466",
    "url": "assets/images/gameover/block.png"
  },
  {
    "revision": "e9d74707a3b6d752219c5c3d21b0bb1c",
    "url": "assets/images/gameover/end.png"
  },
  {
    "revision": "83373ffcb7acabd970213a197b4dacd4",
    "url": "assets/images/gameover/floris.png"
  },
  {
    "revision": "1272244fed1094b6457674ba6995d0e2",
    "url": "assets/images/gameover/lines.png"
  },
  {
    "revision": "cdc6de18e2d1eba26d61d19dd61c37c4",
    "url": "assets/images/gameover/rub.png"
  },
  {
    "revision": "88e52f3fdb75354a94d85746ce7418d3",
    "url": "assets/images/gameover/salvini-1.png"
  },
  {
    "revision": "d762ff7075288d9a55ef327f1833066f",
    "url": "assets/images/gameover/salvini-2.png"
  },
  {
    "revision": "14a2b199ba4420e21c4304f5091c003f",
    "url": "assets/images/how-to.png"
  },
  {
    "revision": "fb4507f741ffd535eabf0969619bfa8a",
    "url": "assets/images/lingua.png"
  },
  {
    "revision": "8e240a8507243a4f9c004bf3c91e1400",
    "url": "assets/images/muzzleflash3.png"
  },
  {
    "revision": "c44bbaf68f8f0e499e1e71c0fd1e791b",
    "url": "assets/images/random-end.png"
  },
  {
    "revision": "9afc6a5cc030f9c709c67d839588d054",
    "url": "assets/images/rublo.png"
  },
  {
    "revision": "957c92238f6918b328d1f501a7b2b564",
    "url": "assets/images/salvini.png"
  },
  {
    "revision": "b1823c9e8ea7cffd6c524f33a898fc14",
    "url": "assets/images/scanlines.png"
  },
  {
    "revision": "dfd9565b9e281adea56f825de6735baa",
    "url": "assets/images/sky-level-1.png"
  },
  {
    "revision": "3d8c343368f2a53b3e96600d3385e5c8",
    "url": "assets/images/sky-level-2.png"
  },
  {
    "revision": "3b581a2b1282b5e2ed7e3d46dc639cf5",
    "url": "assets/images/sky-level-3.png"
  },
  {
    "revision": "16507ab55cbe57ce9880cf0446d11ef9",
    "url": "assets/images/sky-level-4.png"
  },
  {
    "revision": "3279ee83da3257e8e009c2f7a4ff69b7",
    "url": "assets/images/slime-1.png"
  },
  {
    "revision": "1048e9ffe8389f7851e68876d8e5600d",
    "url": "assets/images/slime-2.png"
  },
  {
    "revision": "0b28673e7c7c1ccd05611a3259aaffdd",
    "url": "assets/images/slime-3.png"
  },
  {
    "revision": "c2b67181f575fd09a6d2171c8196cd46",
    "url": "assets/images/slime-4.png"
  },
  {
    "revision": "09424004d71d72f98968de3c5cd4cf40",
    "url": "assets/images/slime.png"
  },
  {
    "revision": "8fc96fc7bc1f848d58060817cab71e70",
    "url": "assets/images/smoke-puff.png"
  },
  {
    "revision": "756adaf2de298928d681e5d57081295e",
    "url": "assets/images/smoke0.png"
  },
  {
    "revision": "7eb6934ba1a8336bf99899fdec2714ed",
    "url": "assets/images/thelucasart.png"
  },
  {
    "revision": "19f74d48afb822e0274c37ca929f6439",
    "url": "assets/js/VirtualJoystickPlugin.min.js"
  },
  {
    "revision": "bc7a70b3f280c7445e2437338cce9144",
    "url": "assets/js/firebase.js"
  },
  {
    "revision": "2edc942c0bd2476be8967a9f788d9e26",
    "url": "assets/js/jquery.js"
  },
  {
    "revision": "23dd87c388e80e46a18dd9938619454c",
    "url": "assets/js/rexgestures.js"
  },
  {
    "revision": "e9e9f2003cb2cd6791388f5f605864ab",
    "url": "assets/js/webfonts.js"
  },
  {
    "revision": "ce8e4c3b58135282fa6c5b4d1c1ae84c",
    "url": "assets/skins/arcade-joystick.json"
  },
  {
    "revision": "90749bed30a5288db54325f4a8c88cc2",
    "url": "assets/skins/arcade-joystick.png"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "assets/skins/debug.log"
  },
  {
    "revision": "48cc2fe4cf7c2f17d97246d1d2c42a2e",
    "url": "assets/skins/dpad.json"
  },
  {
    "revision": "e29022f7a3b696997214e6b571dd3e44",
    "url": "assets/skins/dpad.png"
  },
  {
    "revision": "f08377947f286a6794b17d57952fd8ea",
    "url": "assets/skins/generic-joystick.json"
  },
  {
    "revision": "f191fc52284c7bf67d582adcab642e2e",
    "url": "assets/skins/generic-joystick.png"
  },
  {
    "revision": "7d378f9ecd45eb3b0690fe8a812dc33f",
    "url": "assets/skins/spritesheet.json"
  },
  {
    "revision": "4e2bf44a180c3694407bcd850b9c4311",
    "url": "assets/skins/spritesheet.png"
  },
  {
    "revision": "e1d39fd7e1d253d3ec395a217f286207",
    "url": "assets/sounds/alarm.m4a"
  },
  {
    "revision": "0db7f9f1aab438a289cc4cd6baff3c2a",
    "url": "assets/sounds/alarm.ogg"
  },
  {
    "revision": "2f870c54a32621370ddb394ecb0e0209",
    "url": "assets/sounds/boss.m4a"
  },
  {
    "revision": "2fa5511a19efb2ae8f1184626aab7784",
    "url": "assets/sounds/boss.ogg"
  },
  {
    "revision": "eec89fb7a3e466613879f76c176f0946",
    "url": "assets/sounds/frutti.m4a"
  },
  {
    "revision": "ab1f7c9f17415f27cddc335f46db4484",
    "url": "assets/sounds/frutti.ogg"
  },
  {
    "revision": "ce0fbe2f6ce765b62aa607ebe924d670",
    "url": "assets/sounds/game.m4a"
  },
  {
    "revision": "40f3fed8fe0ef7baa7d46eba1f38a900",
    "url": "assets/sounds/game.ogg"
  },
  {
    "revision": "b83c804c3bc0584ea136dc9c1a6015e1",
    "url": "assets/sounds/gameover.m4a"
  },
  {
    "revision": "d2fb02ce0d261f282e649544785fabb1",
    "url": "assets/sounds/gameover.ogg"
  },
  {
    "revision": "ff9b8020c932b8007aeb165753bdd4ce",
    "url": "assets/sounds/heli.m4a"
  },
  {
    "revision": "2630dd4718a27900f08fb8a8053b3e09",
    "url": "assets/sounds/heli.ogg"
  },
  {
    "revision": "c4fa24db8f70f463e595945eb07d98dd",
    "url": "assets/sounds/intro.m4a"
  },
  {
    "revision": "67045bf53899890ce48b4c110ea089fa",
    "url": "assets/sounds/intro.ogg"
  },
  {
    "revision": "eef504c2373046c10167f2143e7dab52",
    "url": "assets/sounds/sfx.json"
  },
  {
    "revision": "fcf2f74e0235d21a3bd84fbe675ef533",
    "url": "assets/sounds/sfx.m4a"
  },
  {
    "revision": "af037f51a47c3b03d0d66bbf53f9a8dd",
    "url": "assets/sounds/sfx.ogg"
  },
  {
    "revision": "87554cee99a05cc3dca03b6ef45704ad",
    "url": "favicon.ico"
  },
  {
    "revision": "4cd19ebd2052c99640c5b7f0c505d2fc",
    "url": "index.html"
  },
  {
    "revision": "7cd50d44cfc5f4e256c5",
    "url": "main.31846364cc08e5c69c8a.bundle.js"
  },
  {
    "revision": "578c2394bc944085db87dc76b4002dff",
    "url": "manifest.json"
  },
  {
    "revision": "301d14d11cfe6dcc0f2d134aa03815d0",
    "url": "sw.js"
  },
  {
    "revision": "449eb695654f0a538da0",
    "url": "vendors.08a84f2e3942d8bb1e2e.bundle.js"
  }
]);